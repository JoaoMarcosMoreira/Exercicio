package com.example.alunos.listadinamica;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.alunos.listadinamica.model.Pessoa;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    ArrayList<Pessoa> lista = new ArrayList<Pessoa>();

    public void showList(View v) {
        Intent it = new Intent(this, mostraListaDinamica.class);
        startActivity(it);
    }

    public void salvarList(View v) {
        EditText textNome = (EditText) v.findViewById(R.id.Nome);
        String Nome = String.valueOf(textNome.getText());
        EditText textTelefone = (EditText) v.findViewById(R.id.Telefone);
        String Telefone = String.valueOf(textTelefone.getText());
        EditText textIdade = (EditText) v.findViewById(R.id.Idade);
        int Idade = Integer.parseInt(String.valueOf(textIdade.getText()));

        lista.add(new Pessoa(Nome, Telefone, Idade));
    }
}